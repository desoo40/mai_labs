create view V_FACT_SALE (FACT_ID, PRODUCT_ID, PRODUCT_NAME, SALES_ORDER_ID, MANAGER_ID, MANAGER_FIRST_NAME,
                         MANAGER_LAST_NAME, OFFICE_ID, OFFICE_NAME, CITY_ID, CITY_NAME, COUNTRY, REGION, SALE_QTY,
                         SALE_PRICE, SALE_AMOUNT, SALE_DATE) as
select ol.ORDER_LINE_ID,
       ol.product_id,
       p.PRODUCT_NAME,
       so.SALES_ORDER_ID,
       so.manager_id,
       m.MANAGER_FIRST_NAME,
       m.MANAGER_LAST_NAME,
       m.office_id,
       o.OFFICE_NAME,
       o.city_id,
       c.CITY_NAME,
       c.COUNTRY,
       c.REGION,
       ol.product_qty,
       ol.product_price,
       ol.product_qty * ol.product_price,
       so.order_date
from sales_order_line ol
         left outer join sales_order so on (so.sales_order_id = ol.sales_order_id)
         left outer join manager m on (m.manager_id = so.manager_id)
         left outer join office o on (m.office_id = o.office_id)
         left outer join city c on (o.CITY_ID = c.city_id)
         left outer join product p on (p.PRODUCT_ID = ol.PRODUCT_ID)
/

